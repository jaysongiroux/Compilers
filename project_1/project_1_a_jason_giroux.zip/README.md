#Post-Lab exercises:
1. Write a program called project1XXX.tny in TINY language which reads
two integer values, calculate their summation, subtraction, multiplication
and division, and output the results in the order as listed. XXX are your
initials. Check the feasibility of the values for division operation (divided
by zero). Output a value of zero if the denominator of the division
operation is zero. Calculate the summation and average of all integers
between the first and the second integer. Compare those two integers to
make sure the range is feasible.
2. Save the file project1XXX.tny in a folder with all the necessary TINY
compiler files in it.
3. Use the TINY compiler to compile and run project1XXX.tny program.
4. Compress your files, which include TINY compiler files and the
project1XXX.tny, and load them to bridges under folder project1. 
